const express = require("express");
const session = require("express-session");
const cors = require("cors");
require("./db");

const authRoutes = require("./routes/auth");

const app = express();

app.use(cors());
app.use(express.json());

app.use(session({
    secret: "gymsecret",
    resave: false,
    saveUninitialized: true
}));

app.use("/api", authRoutes);

app.get("/", (req, res) => {
    res.send("Gym Backend Running");
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
