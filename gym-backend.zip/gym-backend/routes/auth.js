const express = require("express");
const bcrypt = require("bcryptjs");
const User = require("../models/User");

const router = express.Router();

router.post("/login", async (req, res) => {
    console.log("REQ BODY:", req.body); // DEBUG

    const { email, password } = req.body;

    if (!email || !password) {
        return res.send("Email or password missing");
    }

    const user = await User.findOne({ email });
    if (!user) return res.send("User not found");

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.send("Wrong password");

    res.send("Login Successful");
});

router.post("/register", async (req, res) => {
    const { email, password } = req.body;

    const hash = await bcrypt.hash(password, 10);

    await User.create({
        email,
        password: hash
    });

    res.send("Registered Successfully");
});

module.exports = router;
